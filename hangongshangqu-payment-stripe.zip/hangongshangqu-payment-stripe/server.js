const express = require('express') 
const bodyparser = require('body-parser') 
const path = require('path') 
const app = express() 

var Publishable_Key = 'pk_test_51JDZIrBdb2LxfD6neE7dtp4hL1i5Cn4YmQtyNZyfJnF8fULzYWK6UvSgoNYQK6LDM11W0xBsuCxnETk177jPsN8B00zMzHTPci'
var Secret_Key = 'sk_test_51JDZIrBdb2LxfD6nsUzMkRVdH1qAUBxnfw5mwDeBzzycgvquxpgRto55eidPA7QkEgPXmTo6QGr4XSXFnHLVco0p00482azDc1'

const stripe = require('stripe')(Secret_Key) 

const port = process.env.PORT || 7070 

app.use(bodyparser.urlencoded({extended:false})) 
app.use(bodyparser.json()) 

// View Engine Setup 
// app.set('views', path.join(__dirname, 'views')) 
// app.set('view engine', 'ejs') 

app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);

app.get('/', function(req, res){ 
    res.render('payment.html', { 
    key: Publishable_Key 
    }) 
}) 

app.post('/payment', function(req, res){ 

    // Moreover you can take more details from user 
    // like Address, Name, etc from form 
    stripe.customers.create({ 
        email: req.body.stripeEmail, 
        source: req.body.stripeToken, 
        name: 'Gautam Sharma', 
        address: { 
            line1: 'TC 9/4 Old MES colony', 
            postal_code: '110092', 
            city: 'New Delhi', 
            state: 'Delhi', 
            country: 'India', 
        } 
    }) 
    .then((customer) => { 

        return stripe.charges.create({ 
            amount: 6599,    // Charing Rs 25
            description: 'Web Development Product', 
            currency: 'USD', 
            customer: customer.id 
        }); 
    }) 
    .then((charge) => { 
        // res.send("Success") // If no error occurs 
        res.sendFile(path.join(__dirname, '/views/payment_successfully.html'));
       
    }) 
    .catch((err) => { 
        res.send(err)    // If some error occurs 
    }); 
}) 

app.listen(port, function(error){ 
    if(error) throw error 
    console.log("Server created Successfully port 7070") 
})